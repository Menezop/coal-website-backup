/**
 * ================================================
 * COAL - TRADUÇÕES
 * ================================================
 * 
 * Este arquivo contém todas as strings de texto do site
 * organizadas por idioma (português e inglês).
 * 
 * Para adicionar um novo idioma, basta copiar a estrutura
 * e traduzir os textos.
 * 
 * Autor: Menezop (https://github.com/Menezop)
 */

/**
 * Objeto principal com todas as traduções
 * Cada idioma é uma chave com um objeto aninhado
 */
const TRADUCOES = {
    
    // ================================================
    // PORTUGUÊS (Brasil)
    // ================================================
    pt: {
        // ----- Navegação -----
        nav: {
            features: "Recursos",
            about: "Sobre",
            download: "Baixar"
        },
        
        // ----- Seção Hero -----
        hero: {
            title: "Um app de chat para pessoas que só querem conversar.",
            subtitle: "Um aplicativo de chat desktop construído para comunidades brasileiras que querem algo leve, honesto e delas.",
            description: "Sem anúncios. Sem verificação de idade. Sem bobagem corporativa. Apenas servidores, canais e pessoas.",
            github: "Ver no GitHub"
        },
        
        // ----- Seção de Recursos -----
        features: {
            title: "O que é",
            subtitle: "Tudo que você precisa, nada que você não precisa.",
            items: [
                {
                    title: "Servidores e Canais",
                    description: "Crie comunidades organizadas do jeito que você quer. Servidores e canais dão estrutura às suas conversas sem bagunça."
                },
                {
                    title: "Mensagens em Tempo Real",
                    description: "Mensagens instantâneas com Supabase. Suas palavras chegam aos outros tão rápido quanto você consegue digitá-las."
                },
                {
                    title: "Upload de Arquivos",
                    description: "Compartilhe imagens, documentos e mais. Envie arquivos diretamente no chat e mantenha a conversa fluindo."
                },
                {
                    title: "Perfis de Usuário",
                    description: "Expresse-se. Perfis personalizáveis permitem mostrar quem você é para sua comunidade."
                },
                {
                    title: "Convites",
                    description: "Cresça sua comunidade com links de convite simples. Compartilhe acesso com as pessoas que importam."
                },
                {
                    title: "Interface Personalizável",
                    description: "Uma interface escura com cores e fontes personalizáveis. Você passa muito tempo aqui—deveria sentir-se certo."
                }
            ]
        },
        
        // ----- Seção Sobre -----
        about: {
            title: "Construído de forma diferente",
            subtitle: "Inspirado no que Stoat queria ser — aberto, orientado pela comunidade, livre do peso que o Discord acumulou por anos — mas construído do zero com uma stack mais simples e foco em não atrapalhar você.",
            tech: {
                title: "Construído com",
                items: [
                    { 
                        name: "Electron", 
                        description: "App desktop para Linux e Windows" 
                    },
                    { 
                        name: "Supabase", 
                        description: "Autenticação, armazenamento e comunicação em tempo real" 
                    }
                ]
            }
        },
        
        // ----- Rodapé -----
        footer: {
            tagline: "Um projeto movido pela comunidade",
            coalAuthor: "Coal por",
            siteAuthor: "Site por",
            links: {
                github: "Repositório GitHub",
                owner: "ellisdevnuts",
                developer: "Menezop"
            }
        }
    },
    
    // ================================================
    // INGLÊS
    // ================================================
    en: {
        // ----- Navigation -----
        nav: {
            features: "Features",
            about: "About",
            download: "Download"
        },
        
        // ----- Hero Section -----
        hero: {
            title: "A chat app for people who just want to talk.",
            subtitle: "A desktop chat app built for Brazilian communities who want something lightweight, honest, and theirs.",
            description: "No ads. No age verification. No corporate nonsense. Just servers, channels, and people.",
            github: "View on GitHub"
        },
        
        // ----- Features Section -----
        features: {
            title: "What it is",
            subtitle: "Everything you need, nothing you don't.",
            items: [
                {
                    title: "Servers & Channels",
                    description: "Create communities organized the way you want. Servers and channels give your conversations structure without the clutter."
                },
                {
                    title: "Real-time Messages",
                    description: "Instant messaging powered by Supabase. Your words reach others as fast as you can type them."
                },
                {
                    title: "File Uploads",
                    description: "Share images, documents, and more. Upload files directly in chat and keep the conversation flowing."
                },
                {
                    title: "User Profiles",
                    description: "Express yourself. Customizable profiles let you show who you are to your community."
                },
                {
                    title: "Invites",
                    description: "Grow your community with simple invite links. Share access with the people who matter."
                },
                {
                    title: "Customizable Interface",
                    description: "A dark interface with customizable colors and fonts. You spend a lot of time here—it should feel right."
                }
            ]
        },
        
        // ----- About Section -----
        about: {
            title: "Built differently",
            subtitle: "Inspired by what Stoat set out to be — open, community-driven, free from the baggage that Discord has been accumulating for years — but built from scratch with a simpler stack and a focus on getting out of your way.",
            tech: {
                title: "Built with",
                items: [
                    { 
                        name: "Electron", 
                        description: "Desktop app for Linux and Windows" 
                    },
                    { 
                        name: "Supabase", 
                        description: "Auth, storage, and real-time communication" 
                    }
                ]
            }
        },
        
        // ----- Footer -----
        footer: {
            tagline: "A community-driven project",
            coalAuthor: "Coal by",
            siteAuthor: "Site by",
            links: {
                github: "GitHub Repository",
                owner: "ellisdevnuts",
                developer: "Menezop"
            }
        }
    }
};
