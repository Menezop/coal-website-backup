/**
 * ================================================
 * COAL - SCRIPT PRINCIPAL
 * ================================================
 * 
 * Este arquivo gerencia toda a lógica do site:
 * - Troca de idioma (PT/EN)
 * - Troca de tema (claro/escuro)
 * - Navegação suave
 * - Preferências do usuário
 * 
 * Autor: Menezop (https://github.com/Menezop)
 */

/* ================================================
   CONFIGURAÇÃO INICIAL
   ================================================ */

/**
 * Configurações padrão do site
 */
const CONFIG = {
    idiomaPadrao: 'pt',      // Idioma padrão (pt = português)
    temaPadrao: 'dark',       // Tema padrão (dark = escuro)
    chaveIdioma: 'coal-idioma',   // Chave para salvar idioma no localStorage
    chaveTema: 'coal-tema'        // Chave para salvar tema no localStorage
};

/**
 * Estado atual da aplicação
 * Armazena as configurações ativas no momento
 */
const estado = {
    idioma: CONFIG.idiomaPadrao,
    tema: CONFIG.temaPadrao
};

/* ================================================
   ELEMENTOS DO DOM
   Seleciona os elementos que serão manipulados
   ================================================ */

const elementos = {
    // Botões de controle
    btnIdioma: document.getElementById('btn-idioma'),
    btnTema: document.getElementById('btn-tema'),
    
    // Ícones do tema
    iconeSol: document.getElementById('icone-sol'),
    iconeLua: document.getElementById('icone-lua'),
    
    // Ano atual no rodapé
    anoAtual: document.getElementById('ano-atual')
};

/* ================================================
   FUNÇÕES DE INICIALIZAÇÃO
   ================================================ */

/**
 * Função principal que inicializa toda a aplicação
 * Chamada quando o DOM estiver completamente carregado
 */
function inicializar() {
    // Carrega as preferências salvas do usuário
    carregarPreferencias();
    
    // Configura os event listeners (ouvintes de eventos)
    configurarEventListeners();
    
    // Aplica o idioma inicial
    aplicarIdioma();
    
    // Atualiza os ícones do tema
    atualizarIconesTema();
    
    // Define o ano atual no rodapé
    definirAnoAtual();
    
    console.log('✓ Site do Coal inicializado com sucesso!');
}

/**
 * Carrega as preferências do usuário do localStorage
 * Se não houver preferências salvas, usa os valores padrão
 */
function carregarPreferencias() {
    // Carrega o idioma salvo
    const idiomaSalvo = localStorage.getItem(CONFIG.chaveIdioma);
    if (idiomaSalvo && tradicaoExiste(idiomaSalvo)) {
        estado.idioma = idiomaSalvo;
    }
    
    // Carrega o tema salvo
    const temaSalvo = localStorage.getItem(CONFIG.chaveTema);
    if (temaSalvo === 'light' || temaSalvo === 'dark') {
        estado.tema = temaSalvo;
        aplicarTema(estado.tema);
    }
}

/**
 * Verifica se uma tradução existe para o idioma informado
 * @param {string} idioma - Código do idioma (pt ou en)
 * @returns {boolean} - True se existir, false caso contrário
 */
function tradicaoExiste(idioma) {
    return TRADUCOES.hasOwnProperty(idioma);
}

/* ================================================
   EVENT LISTENERS
   ================================================ */

/**
 * Configura todos os ouvintes de eventos do site
 */
function configurarEventListeners() {
    // Evento de clique no botão de idioma
    elementos.btnIdioma.addEventListener('click', alternarIdioma);
    
    // Evento de clique no botão de tema
    elementos.btnTema.addEventListener('click', alternarTema);
    
    // Navegação suave para links internos (com #)
    configurarNavegacaoSuave();
}

/**
 * Configura a navegação suave para links que apontam
 * para seções da mesma página (href="#secao")
 */
function configurarNavegacaoSuave() {
    // Seleciona todos os links que começam com #
    const linksInternos = document.querySelectorAll('a[href^="#"]');
    
    linksInternos.forEach(function(link) {
        link.addEventListener('click', function(evento) {
            evento.preventDefault();
            
            // Pega o ID da seção alvo (remove o #)
            const idAlvo = this.getAttribute('href').substring(1);
            const elementoAlvo = document.getElementById(idAlvo);
            
            if (elementoAlvo) {
                // Rola suavemente até o elemento
                elementoAlvo.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

/* ================================================
   FUNÇÕES DE IDIOMA
   ================================================ */

/**
 * Alterna entre os idiomas português e inglês
 */
function alternarIdioma() {
    // Troca o idioma atual
    estado.idioma = estado.idioma === 'pt' ? 'en' : 'pt';
    
    // Salva a preferência no localStorage
    salvarPreferencia(CONFIG.chaveIdioma, estado.idioma);
    
    // Aplica as traduções na página
    aplicarIdioma();
    
    console.log(`✓ Idioma alterado para: ${estado.idioma.toUpperCase()}`);
}

/**
 * Aplica as traduções do idioma atual em todos os elementos
 * que possuem o atributo data-i18n
 */
function aplicarIdioma() {
    const traducoes = TRADUCOES[estado.idioma];
    
    // Atualiza o texto do botão de idioma
    elementos.btnIdioma.textContent = estado.idioma === 'pt' ? 'EN' : 'PT';
    
    // Atualiza o atributo lang do HTML
    document.documentElement.lang = estado.idioma === 'pt' ? 'pt-BR' : 'en';
    
    // ----- Navegação -----
    atualizarTexto('[data-i18n="nav.features"]', traducoes.nav.features);
    atualizarTexto('[data-i18n="nav.about"]', traducoes.nav.about);
    atualizarTexto('[data-i18n="nav.download"]', traducoes.nav.download);
    
    // ----- Hero -----
    atualizarTexto('[data-i18n="hero.title"]', traducoes.hero.title);
    atualizarTexto('[data-i18n="hero.subtitle"]', traducoes.hero.subtitle);
    atualizarTexto('[data-i18n="hero.description"]', traducoes.hero.description);
    atualizarTexto('[data-i18n="hero.github"]', traducoes.hero.github);
    
    // ----- Recursos -----
    atualizarTexto('[data-i18n="features.title"]', traducoes.features.title);
    atualizarTexto('[data-i18n="features.subtitle"]', traducoes.features.subtitle);
    
    // Atualiza cada item de recurso
    traducoes.features.items.forEach(function(item, indice) {
        atualizarTexto(`[data-i18n="features.items.${indice}.title"]`, item.title);
        atualizarTexto(`[data-i18n="features.items.${indice}.description"]`, item.description);
    });
    
    // ----- Sobre -----
    atualizarTexto('[data-i18n="about.title"]', traducoes.about.title);
    atualizarTexto('[data-i18n="about.subtitle"]', traducoes.about.subtitle);
    atualizarTexto('[data-i18n="about.tech.title"]', traducoes.about.tech.title);
    
    // Atualiza cada tecnologia
    traducoes.about.tech.items.forEach(function(item, indice) {
        atualizarTexto(`[data-i18n="about.tech.items.${indice}.description"]`, item.description);
    });
    
    // ----- Rodapé -----
    atualizarTexto('[data-i18n="footer.tagline"]', traducoes.footer.tagline);
    atualizarTexto('[data-i18n="footer.coalAuthor"]', traducoes.footer.coalAuthor);
    atualizarTexto('[data-i18n="footer.siteAuthor"]', traducoes.footer.siteAuthor);
}

/**
 * Atualiza o texto de um elemento baseado em um seletor CSS
 * @param {string} seletor - Seletor CSS do elemento
 * @param {string} texto - Novo texto a ser inserido
 */
function atualizarTexto(seletor, texto) {
    const elemento = document.querySelector(seletor);
    if (elemento) {
        elemento.textContent = texto;
    }
}

/* ================================================
   FUNÇÕES DE TEMA
   ================================================ */

/**
 * Alterna entre o modo claro e escuro
 */
function alternarTema() {
    // Troca o tema atual
    estado.tema = estado.tema === 'dark' ? 'light' : 'dark';
    
    // Aplica o tema na página
    aplicarTema(estado.tema);
    
    // Salva a preferência no localStorage
    salvarPreferencia(CONFIG.chaveTema, estado.tema);
    
    // Atualiza os ícones do botão
    atualizarIconesTema();
    
    console.log(`✓ Tema alterado para: ${estado.tema === 'dark' ? 'Escuro' : 'Claro'}`);
}

/**
 * Aplica o tema ao corpo da página
 * @param {string} tema - 'dark' para escuro, 'light' para claro
 */
function aplicarTema(tema) {
    if (tema === 'dark') {
        document.body.classList.add('dark');
    } else {
        document.body.classList.remove('dark');
    }
}

/**
 * Atualiza a visibilidade dos ícones do botão de tema
 * Mostra o ícone apropriado baseado no tema atual
 */
function atualizarIconesTema() {
    const modoEscuro = estado.tema === 'dark';
    
    if (modoEscuro) {
        // Modo escuro ativo: mostra ícone do sol (para mudar para claro)
        elementos.iconeSol.classList.remove('btn__icon--hidden');
        elementos.iconeLua.classList.add('btn__icon--hidden');
    } else {
        // Modo claro ativo: mostra ícone da lua (para mudar para escuro)
        elementos.iconeSol.classList.add('btn__icon--hidden');
        elementos.iconeLua.classList.remove('btn__icon--hidden');
    }
}

/* ================================================
   FUNÇÕES UTILITÁRIAS
   ================================================ */

/**
 * Salva uma preferência no localStorage
 * @param {string} chave - Nome da chave
 * @param {string} valor - Valor a ser salvo
 */
function salvarPreferencia(chave, valor) {
    try {
        localStorage.setItem(chave, valor);
    } catch (erro) {
        console.warn('Não foi possível salvar a preferência:', erro);
    }
}

/**
 * Define o ano atual no elemento do rodapé
 * Usado para o copyright
 */
function definirAnoAtual() {
    if (elementos.anoAtual) {
        elementos.anoAtual.textContent = new Date().getFullYear();
    }
}

/* ================================================
   INICIALIZAÇÃO
   Executa quando o DOM estiver pronto
   ================================================ */

// Aguarda o DOM carregar completamente antes de inicializar
document.addEventListener('DOMContentLoaded', inicializar);
