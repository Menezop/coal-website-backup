/**
 * ================================================
 * COAL - SCRIPT PRINCIPAL
 * Script para gerenciar idioma e tema do site
 * ================================================
 */

/**
 * Traduções do site
 * Cada idioma tem suas próprias strings de texto
 */
const traducoes = {
    // Português (Brasil)
    pt: {
        nav: {
            features: "Recursos",
            about: "Sobre",
            download: "Baixar"
        },
        hero: {
            title: "Um app de chat para pessoas que só querem conversar.",
            subtitle: "Um aplicativo de chat desktop construído para comunidades brasileiras que querem algo leve, honesto e delas.",
            description: "Sem anúncios. Sem verificação de idade. Sem bobagem corporativa. Apenas servidores, canais e pessoas.",
            github: "Ver no GitHub"
        },
        features: {
            title: "O que é",
            subtitle: "Tudo que você precisa, nada que você não precisa.",
            items: [
                {
                    title: "Servidores e Canais",
                    description: "Crie comunidades organizadas do jeito que você quer. Servidores e canais dão estrutura às suas conversas sem bagunça."
                },
                {
                    title: "Mensagens em Tempo Real",
                    description: "Mensagens instantâneas com Supabase. Suas palavras chegam aos outros tão rápido quanto você consegue digitá-las."
                },
                {
                    title: "Upload de Arquivos",
                    description: "Compartilhe imagens, documentos e mais. Envie arquivos diretamente no chat e mantenha a conversa fluindo."
                },
                {
                    title: "Perfis de Usuário",
                    description: "Expresse-se. Perfis personalizáveis permitem mostrar quem você é para sua comunidade."
                },
                {
                    title: "Convites",
                    description: "Cresça sua comunidade com links de convite simples. Compartilhe acesso com as pessoas que importam."
                },
                {
                    title: "Interface Personalizável",
                    description: "Uma interface escura com cores e fontes personalizáveis. Você passa muito tempo aqui—deveria sentir-se certo."
                }
            ]
        },
        about: {
            title: "Construído de forma diferente",
            subtitle: "Inspirado no que Stoat queria ser — aberto, orientado pela comunidade, livre do peso que o Discord acumulou por anos — mas construído do zero com uma stack mais simples e foco em não atrapalhar você.",
            tech: {
                title: "Construído com",
                items: [
                    { name: "Electron", description: "App desktop para Linux e Windows" },
                    { name: "Supabase", description: "Autenticação, armazenamento e comunicação em tempo real" }
                ]
            }
        },
        footer: {
            tagline: "Um projeto movido pela comunidade",
            made: "Feito com carinho por",
            links: {
                github: "Repositório GitHub",
                owner: "ellisdevnuts"
            }
        }
    },
    
    // Inglês
    en: {
        nav: {
            features: "Features",
            about: "About",
            download: "Download"
        },
        hero: {
            title: "A chat app for people who just want to talk.",
            subtitle: "A desktop chat app built for Brazilian communities who want something lightweight, honest, and theirs.",
            description: "No ads. No age verification. No corporate nonsense. Just servers, channels, and people.",
            github: "View on GitHub"
        },
        features: {
            title: "What it is",
            subtitle: "Everything you need, nothing you don't.",
            items: [
                {
                    title: "Servers & Channels",
                    description: "Create communities organized the way you want. Servers and channels give your conversations structure without the clutter."
                },
                {
                    title: "Real-time Messages",
                    description: "Instant messaging powered by Supabase. Your words reach others as fast as you can type them."
                },
                {
                    title: "File Uploads",
                    description: "Share images, documents, and more. Upload files directly in chat and keep the conversation flowing."
                },
                {
                    title: "User Profiles",
                    description: "Express yourself. Customizable profiles let you show who you are to your community."
                },
                {
                    title: "Invites",
                    description: "Grow your community with simple invite links. Share access with the people who matter."
                },
                {
                    title: "Customizable Interface",
                    description: "A dark interface with customizable colors and fonts. You spend a lot of time here—it should feel right."
                }
            ]
        },
        about: {
            title: "Built differently",
            subtitle: "Inspired by what Stoat set out to be — open, community-driven, free from the baggage that Discord has been accumulating for years — but built from scratch with a simpler stack and a focus on getting out of your way.",
            tech: {
                title: "Built with",
                items: [
                    { name: "Electron", description: "Desktop app for Linux and Windows" },
                    { name: "Supabase", description: "Auth, storage, and real-time communication" }
                ]
            }
        },
        footer: {
            tagline: "A community-driven project",
            made: "Made with care by",
            links: {
                github: "GitHub Repository",
                owner: "ellisdevnuts"
            }
        }
    }
};

/**
 * Estado atual da aplicação
 */
let idiomaAtual = 'pt';  // Idioma padrão é português

/**
 * Elementos do DOM que serão manipulados
 */
const botaoIdioma = document.getElementById('lang-toggle');
const botaoTema = document.getElementById('theme-toggle');
const iconeSol = document.getElementById('icon-sun');
const iconeLua = document.getElementById('icon-moon');

/**
 * Inicializa a aplicação quando o DOM estiver pronto
 */
document.addEventListener('DOMContentLoaded', function() {
    // Carrega preferências salvas
    carregarPreferencias();
    
    // Configura os event listeners
    configurarEventListeners();
    
    // Aplica o idioma inicial
    aplicarIdioma();
    
    // Atualiza os ícones do tema
    atualizarIconesTema();
});

/**
 * Carrega as preferências do usuário do localStorage
 */
function carregarPreferencias() {
    // Carrega o idioma salvo ou usa o padrão
    const idiomaSalvo = localStorage.getItem('coal-idioma');
    if (idiomaSalvo && (idiomaSalvo === 'pt' || idiomaSalvo === 'en')) {
        idiomaAtual = idiomaSalvo;
    }
    
    // Carrega o tema salvo ou usa o padrão (escuro)
    const temaSalvo = localStorage.getItem('coal-tema');
    if (temaSalvo === 'light') {
        document.body.classList.remove('dark');
    } else {
        document.body.classList.add('dark');
    }
}

/**
 * Configura os event listeners dos botões
 */
function configurarEventListeners() {
    // Botão de troca de idioma
    botaoIdioma.addEventListener('click', alternarIdioma);
    
    // Botão de troca de tema
    botaoTema.addEventListener('click', alternarTema);
    
    // Navegação suave para links internos
    document.querySelectorAll('a[href^="#"]').forEach(function(link) {
        link.addEventListener('click', function(evento) {
            evento.preventDefault();
            const alvo = document.querySelector(this.getAttribute('href'));
            if (alvo) {
                alvo.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

/**
 * Alterna entre os idiomas português e inglês
 */
function alternarIdioma() {
    // Troca o idioma
    idiomaAtual = idiomaAtual === 'pt' ? 'en' : 'pt';
    
    // Salva a preferência
    localStorage.setItem('coal-idioma', idiomaAtual);
    
    // Atualiza o texto do botão
    botaoIdioma.textContent = idiomaAtual === 'pt' ? 'EN' : 'PT';
    
    // Aplica as traduções
    aplicarIdioma();
}

/**
 * Aplica as traduções do idioma atual aos elementos do DOM
 */
function aplicarIdioma() {
    const t = traducoes[idiomaAtual];
    
    // Atualiza o texto do botão de idioma
    botaoIdioma.textContent = idiomaAtual === 'pt' ? 'EN' : 'PT';
    
    // Atualiza os textos da navegação
    atualizarTexto('[data-i18n="nav.features"]', t.nav.features);
    atualizarTexto('[data-i18n="nav.about"]', t.nav.about);
    atualizarTexto('[data-i18n="nav.download"]', t.nav.download);
    
    // Atualiza os textos do hero
    atualizarTexto('[data-i18n="hero.title"]', t.hero.title);
    atualizarTexto('[data-i18n="hero.subtitle"]', t.hero.subtitle);
    atualizarTexto('[data-i18n="hero.description"]', t.hero.description);
    atualizarTexto('[data-i18n="hero.github"]', t.hero.github);
    
    // Atualiza os textos da seção de recursos
    atualizarTexto('[data-i18n="features.title"]', t.features.title);
    atualizarTexto('[data-i18n="features.subtitle"]', t.features.subtitle);
    
    // Atualiza cada item de recurso
    t.features.items.forEach(function(item, indice) {
        atualizarTexto(`[data-i18n="features.items.${indice}.title"]`, item.title);
        atualizarTexto(`[data-i18n="features.items.${indice}.description"]`, item.description);
    });
    
    // Atualiza os textos da seção sobre
    atualizarTexto('[data-i18n="about.title"]', t.about.title);
    atualizarTexto('[data-i18n="about.subtitle"]', t.about.subtitle);
    atualizarTexto('[data-i18n="about.tech.title"]', t.about.tech.title);
    
    // Atualiza cada item de tecnologia
    t.about.tech.items.forEach(function(item, indice) {
        atualizarTexto(`[data-i18n="about.tech.items.${indice}.description"]`, item.description);
    });
    
    // Atualiza os textos do rodapé
    atualizarTexto('[data-i18n="footer.tagline"]', t.footer.tagline);
    atualizarTexto('[data-i18n="footer.made"]', t.footer.made);
    atualizarTexto('[data-i18n="footer.links.owner"]', t.footer.links.owner);
    
    // Atualiza o atributo lang do HTML
    document.documentElement.lang = idiomaAtual === 'pt' ? 'pt-BR' : 'en';
}

/**
 * Atualiza o texto de um elemento selecionado por seletor CSS
 * @param {string} seletor - Seletor CSS do elemento
 * @param {string} texto - Novo texto para o elemento
 */
function atualizarTexto(seletor, texto) {
    const elemento = document.querySelector(seletor);
    if (elemento) {
        elemento.textContent = texto;
    }
}

/**
 * Alterna entre o modo claro e escuro
 */
function alternarTema() {
    // Verifica se está no modo escuro
    const modoEscuro = document.body.classList.contains('dark');
    
    if (modoEscuro) {
        // Muda para modo claro
        document.body.classList.remove('dark');
        localStorage.setItem('coal-tema', 'light');
    } else {
        // Muda para modo escuro
        document.body.classList.add('dark');
        localStorage.setItem('coal-tema', 'dark');
    }
    
    // Atualiza os ícones
    atualizarIconesTema();
}

/**
 * Atualiza os ícones do botão de tema conforme o tema atual
 */
function atualizarIconesTema() {
    const modoEscuro = document.body.classList.contains('dark');
    
    if (modoEscuro) {
        // Mostra o ícone do sol (para mudar para claro)
        iconeSol.classList.remove('hidden');
        iconeLua.classList.add('hidden');
    } else {
        // Mostra o ícone da lua (para mudar para escuro)
        iconeSol.classList.add('hidden');
        iconeLua.classList.remove('hidden');
    }
}
